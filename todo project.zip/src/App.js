import React from 'react';
import logo from './logo.svg';
import './App.css';


class Summary extends React.Component{
  constructor(props){
    super(props)
    this.handleActive=this.handleActive.bind(this);
    this.handleCompleted=this.handleCompleted.bind(this);
    this.handleAll=this.handleAll.bind(this);
  }
  handleCompleted(){  
    this.props.isActive(0);  
  }

  handleActive(){  
    this.props.isActive(1);  
  }

  handleAll(){
    this.props.isActive(2);
  }
  render()
  {
    
      let active=this.props.listItems.filter((doing)=>!doing.isCheck);
      let completed=this.props.listItems.length-active.length;
      return(
        <div>
          {/*}{this.props.listItems.length}  active:{active.length}  completed:{completed}*/}
          <button onClick={this.handleActive}>Active</button>
          <button onClick={this.handleCompleted}>Completed</button>
          <button onClick={this.handleAll}>All</button>
          </div>
      )
  }
}

class Draw extends React.Component{
  constructor(props) {
    super(props);
    this.onRemove=this.onRemove.bind(this);
    this.handleCheckboxChang=this.handleCheckboxChange.bind(this);
  }
    onRemove(index){
      this.props.remove(index);
    }
    
    handleCheckboxChange(index)
    {
      this.props.complete(index);
    }

    render()
    {
      let listItems=this.props.listItems;
      if(this.props.isActive===1)
        listItems=this.props.listItems.filter(doing=>!doing.isCheck);
      else if(this.props.isActive===0)
        listItems=this.props.listItems.filter(doing=>doing.isCheck);
      listItems= listItems.map((doing,index) =>
      { 
      let check='';
      if(doing.isCheck)
          check="checkbox";
      return(
        <li id={doing.id} className={check}>{doing.value} 
      <input name="input" checked={doing.isCheck} onChange={(e)=>this.handleCheckboxChang(doing.id)} type="checkbox"/>
      <button onClick={()=>this.onRemove(doing.id)}>
      remove
      </button>
      </li>)})

    return(
      <ul className="todo">
        {listItems}
      </ul>
    )
  } 
}
 
class Todo extends React.Component{
  constructor(props) {
    super(props);
    this.state = {
      value:'',
      list:[],
      isActive:2
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleRemove=this.handleRemove.bind(this);
    this.handleIsCompleted=this.handleIsCompleted.bind(this);
    this.handleActive=this.handleActive.bind(this);
  }
  
  handleChange(event){
      this.setState({value: event.target.value});
  }

  handleSubmit(event) {
    const value=this.state.value;
    if(this.state.value!='')
      this.setState({value:'',list:this.state.list.concat([{value:this.state.value,isCheck:false,id:Math.floor(Math.random() * 1000)}])});
      event.preventDefault();
  }
  handleRemove(index){
    let arr=this.state.list;
    index=arr.find(element=>element.id===index);
    index=arr.indexOf(index);
    arr.splice(index,1)
    this.setState({list:arr});
  }
  handleIsCompleted(index){
    let arr=this.state.list;
    index=arr.find(element=>element.id===index);
    index=arr.indexOf(index);
    let isComplete=!this.state.list[index].isCheck;
    let copy=[...this.state.list];
    copy[index].isCheck=isComplete;
    this.setState({list:copy});
  }

    handleActive(index){
      this.setState({isActive:index})
    }

  render(){
    return(
      <form onSubmit={this.handleSubmit}>
        <label>
          Name:
          <input type="text" value={this.state.value} onChange={this.handleChange} />
        </label>
        <input type="submit" value="Submit" />
        <Draw isActive={this.state.isActive} listItems={this.state.list} remove={this.handleRemove} complete={this.handleIsCompleted} />
        <Summary listItems={this.state.list} isActive={this.handleActive}/>
      </form>
    )
  }
}

function App() {
  return (
    <div className="App">
      <Todo/>
    </div>
  );
}

export default App;
